/**
 * Contains listeners that handle {@link world.bentobox.bentobox.api.flags.Flag.Type#PROTECTION PROTECTION} flags.
 * @since 1.3.0
 */
package world.bentobox.bentobox.listeners.flags.protection;
