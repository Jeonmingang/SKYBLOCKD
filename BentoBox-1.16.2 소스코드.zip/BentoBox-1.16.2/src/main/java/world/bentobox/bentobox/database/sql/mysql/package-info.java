/**
 * Contains MySQL database managers.
 */
package world.bentobox.bentobox.database.sql.mysql;