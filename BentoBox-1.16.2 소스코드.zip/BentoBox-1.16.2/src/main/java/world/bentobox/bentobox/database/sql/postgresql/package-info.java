/**
 * Contains PostgreSQL database managers.
 * @since 1.6.0
 */
package world.bentobox.bentobox.database.sql.postgresql;