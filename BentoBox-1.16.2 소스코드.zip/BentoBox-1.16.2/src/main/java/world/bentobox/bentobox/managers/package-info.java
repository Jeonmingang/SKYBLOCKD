/**
 * Contains managers.
 * Managers are classes that handle databases or a specific aspect of BentoBox's features.
 */
package world.bentobox.bentobox.managers;
