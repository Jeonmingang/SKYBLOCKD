/**
 * Contains SQLite database managers.
 * @since 1.6.0
 */
package world.bentobox.bentobox.database.sql.sqlite;