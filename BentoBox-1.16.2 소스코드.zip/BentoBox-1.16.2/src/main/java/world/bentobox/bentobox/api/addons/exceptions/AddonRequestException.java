package world.bentobox.bentobox.api.addons.exceptions;

public class AddonRequestException extends AddonException
{
	private static final long serialVersionUID = -5698456013070166174L;

	public AddonRequestException(String errorMessage) {
		super(errorMessage);
	}
}
