/**
 * Contains MariaDB (MySQL fork) database managers.
 * @since 1.1
 * @author barpec12
 */
package world.bentobox.bentobox.database.sql.mariadb;