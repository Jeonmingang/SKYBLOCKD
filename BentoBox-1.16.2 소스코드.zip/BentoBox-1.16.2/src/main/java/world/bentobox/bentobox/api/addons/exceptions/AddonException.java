package world.bentobox.bentobox.api.addons.exceptions;

public abstract class AddonException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 4203162022348693854L;

    protected AddonException(String errorMessage){
        super("AddonException : " + errorMessage);
    }

}
