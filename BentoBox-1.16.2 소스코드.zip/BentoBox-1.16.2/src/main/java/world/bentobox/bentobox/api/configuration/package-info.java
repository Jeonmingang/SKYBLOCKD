/**
 * Contains API related to configurations.
 */
package world.bentobox.bentobox.api.configuration;